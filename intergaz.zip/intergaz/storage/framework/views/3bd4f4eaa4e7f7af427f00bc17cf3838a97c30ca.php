

<?php $__env->startSection('content'); ?>

	<h1>Welcome Page</h1>
	<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ratione cum, ea, impedit sapiente corrupti a maiores et inventore rem necessitatibus iure enim in doloribus laborum vitae possimus accusantium sed expedita porro at magnam? At aspernatur culpa ratione accusantium iure odio pariatur, odit animi vel ea similique eos labore aliquid consequatur numquam voluptatem asperiores earum temporibus necessitatibus totam est officiis ab! Aliquid veritatis eveniet aspernatur voluptatem distinctio recusandae rem quia. Amet fuga, pariatur perspiciatis iure consectetur illum perferendis est similique doloribus maiores et non vero iusto cupiditate impedit architecto asperiores ipsa voluptates omnis molestias distinctio iste dolor! Culpa ad vitae nobis!</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ais8x\intergaz\resources\views/welcome.blade.php ENDPATH**/ ?>