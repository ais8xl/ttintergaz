

<?php $__env->startSection('content'); ?>

	<h1>Atskaite “Neaktīvie klienti”</h1>
	<table class="table table-hover">
	<thead>
		<tr>
			<th scope="col">Klienta nosaukums</th>
			<th scope="col">Piegādes adrese</th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $report3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($report->Name); ?></td>
			<td><?php echo e($report->Title); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ais8x\intergaz\resources\views/Atskaite3.blade.php ENDPATH**/ ?>