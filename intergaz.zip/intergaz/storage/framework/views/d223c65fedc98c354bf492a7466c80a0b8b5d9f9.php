

<?php $__env->startSection('content'); ?>

<h1>Atskaite “Pasūtījumu tipi”</h1>
<table class="table table-hover">
	<thead>
		<tr>
			<th scope="col">Klienta nosaukums</th>
			<th scope="col">Piegādes adrese</th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $multipleDel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliveries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($deliveries->Name); ?></td>
			<td><?php echo e($deliveries->Title); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ais8x\intergaz\resources\views/Atskaite1.blade.php ENDPATH**/ ?>