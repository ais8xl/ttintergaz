

<?php $__env->startSection('content'); ?>

<h1>Klientu Saraksts</h1>
<table class="table table-striped table-hover">
    <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col"></th>
            <th scope="col">Address</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $clientName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td id="name_<?php echo e($name->ID); ?>"><?php echo e($name->Name); ?></td>
            <td>
              <button type="button" class="btn btn-primary" onclick="showClientAddress(<?php echo e($name->ID); ?>)">Parādīt adreses</button>
              <a href="KlientuPiegades<?php echo e($name->ID); ?>" class="btn btn-outline-primary" role="button" aria-disabled="true" id="deliveryName_<?php echo e($name->ID); ?>">Atvērt piegādes</a>
            </td>
            <td id="address_<?php echo e($name->ID); ?>"></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<script>
  function showClientAddress(id) {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $.ajax( {
        type:'POST',
        url:"<?php echo e(route('ajaxRequest.post')); ?>",
        data:{id_client:id},

        success:function(data) {
          $(`#address_${id}`).text(data);
        }
    });
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ais8x\intergaz\resources\views/KlientuSaraksts.blade.php ENDPATH**/ ?>