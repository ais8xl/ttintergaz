

<?php $__env->startSection('content'); ?>

<h1>Klientu Piegades</h1>
<table class="table table-hover">
	<thead>
		<tr>
			<th scope="col">Client</th>
			<th scope="col"></th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $clDel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td id="client_name"><?php echo e($info->Name); ?></td>
			<td></td>
			<th>Piegādes adrese: </th>
			<td><?php echo e($info->Title); ?></td>			
		</tr>
		<tr>
			<td></td>
			<td></td>
			<th>Piegādes datums: </th>
			<td><?php echo e($info->Date); ?></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<th>Preču summa: </th>
			<td><?php echo e($info->QTY); ?></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<th>Piegādes status: </th>
			<td><?php echo e($statuses[$info->Status-1]); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ais8x\intergaz\resources\views/KlientuPiegades.blade.php ENDPATH**/ ?>