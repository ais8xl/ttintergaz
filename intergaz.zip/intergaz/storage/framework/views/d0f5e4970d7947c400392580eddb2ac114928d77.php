<nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
  <div class="container-fluid">
    <a class="navbar-brand" href="/">Intergaz</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="KlientuSaraksts">Klientu saraksts</a>
        <a class="nav-link" href="Atskaite1">Atskaite “Pasūtījumu tipi”</a>
        <a class="nav-link" href="Atskaite2">Atskaite “Pēdējā piegāde”</a>
        <a class="nav-link" href="Atskaite3">Atskaite “Neaktīvie klienti”</a>
      </div>
    </div>
  </div>
</nav><?php /**PATH C:\Users\ais8x\intergaz\resources\views/layouts/nav.blade.php ENDPATH**/ ?>