@ Database monitoring system
The program allows you to view information from the client's database, grouping and displaying data according to certain criteria.

@ Installing

1) Go to .env file and set your parameters.
2) In the root folder use "composer install" command.
3) Install DB file "sql/database.sql".